from google.cloud import storage

def store_audio_to_gcs(audio_bytes,bucket_name):
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket_name)
    blob = bucket.blob("AudioFile.mp3")
    blob.upload_from_string(audio_bytes,content_type="audio/mpeg")
    return "Audio file saved to GCS bucket: "+ bucket_name+"under name: AudioFile.mp3"