from synthesize import text_to_mp3
from htmlscrap import html_to_text

def hello_world(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    request_json = request.get_json()
    
    if request_json and 'url' in request_json:
        return html_to_text( request_json['url'] )
    elif request_json and 'message' in request_json:
        return text_to_mp3("en-US-Wavenet-d", request_json['message'] )
    else:
        return f'No text found!!'
